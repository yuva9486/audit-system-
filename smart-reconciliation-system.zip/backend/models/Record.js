
const mongoose = require("mongoose");
module.exports = mongoose.model("Record", new mongoose.Schema({
  transactionId:String,amount:Number,referenceNumber:String,date:Date
}));
