
import Dashboard from './Dashboard';
function App(){ return <Dashboard/> }
export default App;
